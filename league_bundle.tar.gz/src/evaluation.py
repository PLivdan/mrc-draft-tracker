"""Chronological leave-series-out evaluation and the M0-M4 ladder
(sections 15, 18, 24 and Part I section 5/6 wiring)."""
import hashlib
import json
import multiprocessing as mp
import os
from pathlib import Path

import numpy as np
import pandas as pd

from src.ban_model import BanModel, BanObs
from src.capability import global_prior, team_capability
from src.dataset import replay_decisions, series_of, team_map_usage
from src.draft_state import BAN, BLUE, RED
from src.hero_embedding import hero_embedding
from src.legal_sets import legal_bans, legal_protects
from src.protect_model import ProtectModel, ProtectObs
from src.soft_denial import denial_values, fit_lambda_r, revealed_score
from src.stage_baseline import slot_baselines

LADDER = ("M0", "M1", "M2", "M3", "M4")
HARD_TAU = 1e-4


def _opponent(side):
    return RED if side == BLUE else BLUE


class LadderModel:
    def __init__(self, name, tau=8.0, roles=None):
        assert name in LADDER
        self.name = name
        self.tau = tau
        self.roles = roles or {}
        self._denial_cache = {}

    # ---- fitting -----------------------------------------------------
    def fit(self, train_maps, shared=None):
        """Fit on train_maps. `shared` (a SharedFit from fit_shared()) lets
        the caller inject precomputed usage/g/capability/baselines/
        embedding -- identical across all rungs for a given train_maps --
        and the protect-model/team-value fit -- identical across M2/M3/M4
        -- instead of recomputing them per model. This is purely a
        performance optimization for the league evaluation loop: omitting
        `shared` (the default) reproduces the exact prior behavior."""
        if shared is None:
            roster = sorted(set().union(*[m.roster for m in train_maps]))
            self.roster = roster
            usage = team_map_usage(train_maps)
            usage = usage.reindex(columns=roster, fill_value=0)
            self.g = global_prior(usage, roster)
            self.teams = sorted(usage.index.get_level_values(0).unique())
            self.cap = {t: team_capability(usage, t, roster, self.g)
                        for t in self.teams}
            actions = [a for m in train_maps for a in m.actions]
            self.alpha = slot_baselines(actions, roster)
            self.emb = (hero_embedding(usage, d=3)
                        if self.name in ("M2", "M3", "M4") else None)
        else:
            self.roster = shared.roster
            usage = shared.usage
            self.g = shared.g
            self.teams = shared.teams
            self.cap = shared.cap
            self.alpha = shared.alpha
            self.emb = shared.emb if self.name in ("M2", "M3", "M4") else None
        self._denial_cache = {}
        if self.name == "M0":
            return self
        if self.name == "M1":
            self._fit_pooled(train_maps)
            return self
        if shared is None:
            self._fit_protect(train_maps)
        else:
            self.protect = shared.protect
        if self.name in ("M3", "M4"):
            if shared is None:
                self._team_values(usage)
            else:
                self.lambda_r, self.v, self._r_scores = shared.team_values
        self._fit_ban(train_maps)
        return self

    def _cap_for(self, team):
        return self.cap.get(team, self.g)

    def _aligned(self, series, index, fill):
        """Reindex over legal/pool sets that may contain heroes unseen in
        training (e.g. a roster added between events); fill with a
        conservative "rare hero" prior instead of leaving NaN."""
        return series.reindex(index).fillna(fill)

    def _iter_obs(self, train_maps):
        for m in train_maps:
            for state, a in replay_decisions(m):
                actor = m.teams[a.side]
                opp = m.teams[_opponent(a.side)]
                legal = sorted(
                    legal_bans(state, a.side) if a.kind == BAN
                    else legal_protects(state, a.side)
                )
                yield m, state, a, actor, opp, legal

    def _fit_pooled(self, train_maps):
        obs = []
        for m, state, a, actor, opp, legal in self._iter_obs(train_maps):
            cap_team = opp if a.kind == BAN else actor
            obs.append(BanObs(
                slot="B1",  # routes the single shared coefficient
                legal=tuple(legal),
                chosen=a.hero,
                alpha=self._aligned(self.alpha[a.slot], legal,
                                    self.alpha[a.slot].min()),
                cap_opp=self._aligned(self._cap_for(cap_team), legal,
                                      self.g.min()),
                denial=pd.Series(0.0, index=legal),
            ))
        self.pooled = BanModel().fit(obs, use_denial=False,
                                     stage_specific=False)

    def _fit_protect(self, train_maps):
        obs = []
        for m, state, a, actor, opp, legal in self._iter_obs(train_maps):
            if a.kind == BAN:
                continue
            obs.append(ProtectObs(
                team=actor, slot=a.slot, legal=tuple(legal), chosen=a.hero,
                alpha=self._aligned(self.alpha[a.slot], legal,
                                    self.alpha[a.slot].min()),
                cap=self._aligned(self._cap_for(actor), legal, self.g.min()),
                emb=self.emb.reindex(legal).fillna(0.0),
            ))
        self.protect = ProtectModel().fit(obs)

    def _team_values(self, usage):
        r_scores = {
            t: revealed_score(self.g, self._cap_for(t), self.emb,
                              self.protect.eta.get(t, np.zeros(3)),
                              self.protect.beta_p)
            for t in self.teams
        }
        a0, lam = fit_lambda_r(usage, r_scores)
        self.lambda_r = lam
        self.v = {t: lam * r for t, r in r_scores.items()}
        self._r_scores = r_scores

    def _denial_for(self, state, side, opp_team):
        pool = frozenset(state.roster - set(state.bans_by[side]))
        tau = HARD_TAU if self.name == "M3" else self.tau
        # Denial values are keyed on (pool, opp_team, tau): pools repeat
        # heavily within a fit (every B1 observation uses the full
        # roster), and each denial_values() call re-solves a combinatorial
        # partition function, so this cache is a large win with identical
        # output -- self.v/self.lambda_r/self.g/self.protect are fixed for
        # the lifetime of a single fit() call, and fit() resets this cache
        # before it can go stale across refits.
        key = (pool, opp_team, tau)
        cached = self._denial_cache.get(key)
        if cached is not None:
            return cached
        v_opp = self.v.get(opp_team)
        if v_opp is None:
            v_opp = self.lambda_r * revealed_score(
                self.g, self.g, self.emb, np.zeros(3), self.protect.beta_p
            )
        # v_opp is indexed over the TRAINING roster only; pool may contain
        # heroes unseen in training (roster grew since). Fill with this
        # team's (or the fallback's) own floor before handing to
        # denial_values, since it reindexes over pool internally too.
        v_opp = self._aligned(v_opp, sorted(pool), v_opp.min())
        result = denial_values(v_opp, self.roles, pool, tau)
        self._denial_cache[key] = result
        return result

    def _fit_ban(self, train_maps):
        obs = []
        for m, state, a, actor, opp, legal in self._iter_obs(train_maps):
            if a.kind != BAN:
                continue
            if self.name in ("M3", "M4"):
                den = self._aligned(
                    self._denial_for(state, a.side, opp), legal, 0.0)
            else:
                den = pd.Series(0.0, index=legal)
            obs.append(BanObs(
                slot=a.slot, legal=tuple(legal), chosen=a.hero,
                alpha=self._aligned(self.alpha[a.slot], legal,
                                    self.alpha[a.slot].min()),
                cap_opp=self._aligned(self._cap_for(opp), legal,
                                      self.g.min()),
                denial=den,
            ))
        use_denial = self.name in ("M3", "M4")
        self.ban = BanModel().fit(obs, use_denial=use_denial,
                                  stage_specific=use_denial)

    # ---- prediction --------------------------------------------------
    def predict(self, state, side, kind, slot, actor, opp):
        legal = sorted(
            legal_bans(state, side) if kind == BAN
            else legal_protects(state, side)
        )
        alpha = self._aligned(self.alpha[slot], legal, self.alpha[slot].min())
        if self.name == "M0":
            u = alpha
            p = np.exp(u - u.max())
            return p / p.sum()
        if self.name == "M1":
            cap_team = opp if kind == BAN else actor
            o = BanObs(slot="B1", legal=tuple(legal), chosen=legal[0],
                       alpha=alpha,
                       cap_opp=self._aligned(self._cap_for(cap_team), legal,
                                             self.g.min()),
                       denial=pd.Series(0.0, index=legal))
            return self.pooled.predict(o)
        if kind != BAN:
            return self.protect.predict(
                actor, alpha,
                self._aligned(self._cap_for(actor), legal, self.g.min()),
                self.emb.reindex(legal).fillna(0.0),
            )
        if self.name == "M2":
            den = pd.Series(0.0, index=legal)
        else:
            den = self._aligned(
                self._denial_for(state, side, opp), legal, 0.0)
        o = BanObs(slot=slot, legal=tuple(legal), chosen=legal[0],
                   alpha=alpha,
                   cap_opp=self._aligned(self._cap_for(opp), legal,
                                         self.g.min()),
                   denial=den)
        return self.ban.predict(o)


class SharedFit:
    """Precomputed components shared across LadderModel rungs for a given
    train_maps prefix: usage/g/capability/baselines/embedding are
    identical for all rungs (M0-M4), and the protect-model fit plus
    lambda_r/v/r_scores team values are identical across M2/M3/M4. Built
    once per held-out series by fit_shared() and injected into each rung's
    fit() via its `shared=` argument -- behavior-preserving, just avoids
    redundant recomputation."""

    def __init__(self, roster, usage, g, teams, cap, alpha, emb, protect,
                 team_values):
        self.roster = roster
        self.usage = usage
        self.g = g
        self.teams = teams
        self.cap = cap
        self.alpha = alpha
        self.emb = emb
        self.protect = protect
        self.team_values = team_values


def fit_shared(train_maps, roles=None):
    """Compute the pieces every LadderModel rung would otherwise recompute
    identically from scratch on the same train_maps. Mirrors exactly the
    top of LadderModel.fit(shared=None) plus the M2/M3/M4-shared
    protect-model and team-value fits, so injecting the result via
    `model.fit(train_maps, shared=...)` reproduces bit-identical results
    to independently calling `model.fit(train_maps)` on each rung."""
    roster = sorted(set().union(*[m.roster for m in train_maps]))
    usage = team_map_usage(train_maps)
    usage = usage.reindex(columns=roster, fill_value=0)
    g = global_prior(usage, roster)
    teams = sorted(usage.index.get_level_values(0).unique())
    cap = {t: team_capability(usage, t, roster, g) for t in teams}
    actions = [a for m in train_maps for a in m.actions]
    alpha = slot_baselines(actions, roster)
    emb = hero_embedding(usage, d=3)

    # A throwaway probe carries out the M2/M3/M4-shared protect and
    # team-value fits; neither depends on self.name.
    probe = LadderModel("M2", roles=roles)
    probe.roster, probe.g, probe.teams = roster, g, teams
    probe.cap, probe.alpha, probe.emb = cap, alpha, emb
    probe._fit_protect(train_maps)
    probe._team_values(usage)
    team_values = (probe.lambda_r, probe.v, probe._r_scores)

    return SharedFit(roster, usage, g, teams, cap, alpha, emb, probe.protect,
                     team_values)


def _score_series(model, name, held_out_maps):
    """Score one fitted model against one held-out series' maps. Shared by
    evaluate() and the parallel worker so the two cannot drift apart."""
    rows = []
    for m in held_out_maps:
        for state, a in replay_decisions(m):
            actor = m.teams[a.side]
            opp = m.teams[_opponent(a.side)]
            p = model.predict(state, a.side, a.kind, a.slot, actor, opp)
            order = sorted(p.index, key=lambda h: (-p[h], h))
            rank = order.index(a.hero) + 1
            rows.append({
                "model": name, "map_uid": m.map_uid,
                "series": m.match_id, "slot": a.slot,
                "kind": a.kind, "side": a.side, "chosen": a.hero,
                "rank": rank, "top1": int(rank == 1),
                "top3": int(rank <= 3), "mrr": 1.0 / rank,
                "logloss": float(-np.log(max(p[a.hero], 1e-12))),
                "n_legal": len(p),
            })
    return rows


def evaluate(models, maps, n_warm_series=1):
    groups = series_of(maps)
    rows = []
    for k in range(n_warm_series, len(groups)):
        train = [m for g in groups[:k] for m in g]
        roles = next(iter(models.values())).roles if models else None
        shared = fit_shared(train, roles=roles)
        for name, model in models.items():
            model.fit(train, shared=shared)
            rows.extend(_score_series(model, name, groups[k]))
    return pd.DataFrame(rows)


_WORKER_STATE = {}


def _init_worker(groups, model_specs, checkpoint_dir=None):
    """multiprocessing.Pool initializer (runs once per worker process):
    stash the read-only per-run state so each task only has to pickle its
    held-out series index `k`, not the whole dataset."""
    _WORKER_STATE["groups"] = groups
    _WORKER_STATE["model_specs"] = model_specs
    _WORKER_STATE["checkpoint_dir"] = checkpoint_dir


def _ckpt_file(checkpoint_dir, k):
    return Path(checkpoint_dir) / f"k{k:05d}.json"


def _ckpt_signature(groups, model_specs, n_warm_series):
    """Identifies the run a checkpoint directory belongs to, so a resumed
    run can never splice together rows produced under different data,
    rungs or tau."""
    roles = model_specs[0][2] if model_specs else {}
    return {
        "n_series": len(groups),
        "n_maps": sum(len(g) for g in groups),
        "n_warm_series": n_warm_series,
        "models": [[name, tau] for name, tau, _ in model_specs],
        "roles_digest": hashlib.sha256(
            json.dumps(sorted((roles or {}).items())).encode()
        ).hexdigest(),
    }


def _eval_one_k(k):
    """One held-out series' worth of work: fit fresh M0-M4 instances on
    the chronological prefix groups[:k] (sharing per-k components across
    rungs, exactly as evaluate() does) and predict groups[k]. Independent
    of every other k given its train prefix, so it is safe to run in any
    process and in any order. Returns (k, rows) with `rows` in the same
    model-then-map-then-action order evaluate() emits for that k."""
    groups = _WORKER_STATE["groups"]
    model_specs = _WORKER_STATE["model_specs"]
    train = [m for g in groups[:k] for m in g]
    shared = fit_shared(train, roles=model_specs[0][2] if model_specs
                        else None)
    rows = []
    for name, tau, roles in model_specs:
        model = LadderModel(name, tau=tau, roles=roles)
        model.fit(train, shared=shared)
        rows.extend(_score_series(model, name, groups[k]))
    ckpt = _WORKER_STATE.get("checkpoint_dir")
    if ckpt:
        # Write-then-rename: a kill mid-write leaves the temp file, never a
        # half-written checkpoint that a resume would read back as real rows.
        dest = _ckpt_file(ckpt, k)
        tmp = dest.with_suffix(f".{os.getpid()}.tmp")
        tmp.write_text(json.dumps(rows))
        os.replace(tmp, dest)
    return k, rows


def evaluate_parallel(models, maps, n_warm_series=1, n_workers=4,
                      checkpoint_dir=None):
    """`evaluate()` farmed out across processes, one held-out series per
    task, since each k is independent given its chronological prefix.

    Returns a DataFrame identical to `evaluate()`'s -- same columns, same
    values, same row order: results are collected per-k and concatenated in
    ascending k, which reproduces evaluate()'s k-then-model-then-map
    nesting regardless of the order workers finish in. (Guarded by
    tests/test_evaluation.py::test_evaluate_parallel_matches_evaluate.)

    `checkpoint_dir` makes the sweep resumable: each held-out series' rows
    are written there as they finish and reloaded instead of recomputed on
    a later call. The league sweep runs for hours on a shared machine, so
    an interrupted run must not have to start over. Checkpoints are keyed
    to the dataset/rungs/tau they came from and discarded if those change.

    Intended for the league-scale run, where evaluate()'s sequential cost
    is measured in CPU-days; evaluate() is left as the reference path.
    """
    groups = series_of(maps)
    model_specs = [(m.name, m.tau, m.roles) for m in models.values()]
    ks = list(range(n_warm_series, len(groups)))
    if not ks:
        return pd.DataFrame()

    by_k, todo = {}, ks
    if checkpoint_dir:
        d = Path(checkpoint_dir)
        d.mkdir(parents=True, exist_ok=True)
        sig = _ckpt_signature(groups, model_specs, n_warm_series)
        sig_file = d / "signature.json"
        if sig_file.exists() and json.loads(sig_file.read_text()) != sig:
            for stale in d.glob("k*.json"):
                stale.unlink()
        sig_file.write_text(json.dumps(sig))
        todo = []
        for k in ks:
            f = _ckpt_file(d, k)
            if f.exists():
                try:
                    by_k[k] = json.loads(f.read_text())
                    continue
                except json.JSONDecodeError:
                    f.unlink()
                todo.append(k)
            else:
                todo.append(k)
        if by_k:
            print(f"resuming: {len(by_k)} of {len(ks)} series already "
                  f"checkpointed, {len(todo)} to go", flush=True)
    if todo:
        # Largest (latest) k first: per-k cost grows with the training
        # prefix, so dispatching the biggest jobs first stops the run from
        # ending with one huge task while every other worker sits idle.
        ctx = mp.get_context("spawn")
        with ctx.Pool(processes=n_workers, initializer=_init_worker,
                      initargs=(groups, model_specs, checkpoint_dir)) as pool:
            for k, rows in pool.imap_unordered(_eval_one_k, todo[::-1],
                                               chunksize=1):
                by_k[k] = rows
    return pd.DataFrame([r for k in ks for r in by_k[k]])


def metrics_table(results):
    agg = results.groupby("model").agg(
        Top1=("top1", "mean"), Top3=("top3", "mean"),
        MRR=("mrr", "mean"), LogLoss=("logloss", "mean"),
    )
    return agg


def per_slot_table(results):
    return results.groupby(["model", "slot"]).agg(
        Top1=("top1", "mean"), Top3=("top3", "mean"),
        MRR=("mrr", "mean"), LogLoss=("logloss", "mean"), n=("top1", "size"),
    )


def select_tau(maps, taus=(1, 2.5, 5, 8, 12), n_selection_series=3,
               n_warm_series=1, roles=None):
    groups = series_of(maps)
    upto = min(n_warm_series + n_selection_series, len(groups))
    selection_maps = [m for g in groups[:upto] for m in g]
    best_tau, best_ll = None, np.inf
    for tau in taus:
        res = evaluate({"M4": LadderModel("M4", tau=tau, roles=roles)},
                       selection_maps, n_warm_series=n_warm_series)
        ll = res["logloss"].mean()
        if ll < best_ll:
            best_tau, best_ll = tau, ll
    return best_tau
