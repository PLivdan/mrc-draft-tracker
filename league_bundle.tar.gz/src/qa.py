"""Data QA rules, spec Part II section 22 (rules 1-8 + lineup sanity)."""
from src.draft_state import BAN, BLUE, PHASES, PROTECT, RED, DraftState, \
    IllegalActionError


def validate_map(record, roster):
    violations = []
    actions = record.get("actions") or []

    if len(actions) != 12:
        violations.append(f"expected 12 draft choices, got {len(actions)}")

    expected = {(s.side, s.kind, phase) for phase, slots in PHASES
                for s in slots}
    got = {(a["side"], a["kind"], a["phase"]) for a in actions}
    if got != expected:
        violations.append(
            f"draft structure mismatch: missing {sorted(expected - got)}, "
            f"extra {sorted(got - expected)}"
        )

    off = sorted({a["hero"] for a in actions} - set(roster))
    if off:
        violations.append(f"heroes not in legal roster: {off}")

    # Replay the draft through the state machine: enforces stage order,
    # simultaneity, re-ban and protect legality (rules 4-7).
    if not violations:
        state = DraftState(roster=frozenset(roster))
        by_phase = {}
        for a in actions:
            by_phase.setdefault(a["phase"], {})[a["side"]] = a["hero"]
        try:
            for phase, _ in PHASES:
                state = state.apply_phase(phase, by_phase[phase])
        except (IllegalActionError, KeyError) as exc:
            violations.append(f"illegal draft replay: {exc}")

    for side in (BLUE, RED):
        lineup = (record.get("lineups") or {}).get(side) or []
        if len(lineup) != 6:
            violations.append(f"{side} lineup has {len(lineup)} players")

    return {"status": "pass" if not violations else "reject",
            "violations": violations}
