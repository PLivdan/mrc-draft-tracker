"""Learned hero representation via centered truncated SVD (spec section 4)."""
import numpy as np
import pandas as pd


def hero_embedding(usage, d=3):
    X = usage.to_numpy(dtype=float)
    X = X - X.mean(axis=0, keepdims=True)
    U, S, Vt = np.linalg.svd(X, full_matrices=False)
    k = min(d, int((S > 1e-10).sum()))
    E = Vt[:k].T * np.sqrt(S[:k])
    if k < d:
        E = np.hstack([E, np.zeros((E.shape[0], d - k))])
    # standardize each latent dimension; fix sign deterministically
    for j in range(d):
        sd = E[:, j].std()
        if sd > 1e-12:
            E[:, j] /= sd
        if abs(E[:, j]).max() > 0 and E[np.abs(E[:, j]).argmax(), j] < 0:
            E[:, j] *= -1.0
    return pd.DataFrame(E, index=usage.columns, columns=range(d))
