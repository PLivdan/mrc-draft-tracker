"""Exact role-constrained soft composition value (sections 10-12)."""
import itertools
import math

import numpy as np
import pandas as pd

DEFAULT_PATTERNS = [((2, 2, 2), 0.0), ((1, 3, 2), -0.15), ((3, 1, 2), -0.15)]
ROLE_ORDER = ("Vanguard", "Duelist", "Strategist")

# numpy's NPY_LOGE2 rounded to double -- the constant np.logaddexp adds when
# its two arguments are exactly equal.
_LOGE2 = 0.6931471805599453


def logaddexp(x, y):
    """Scalar `numpy.logaddexp` reimplemented in pure Python.

    This exists purely for speed: the composition DP below evaluates
    logaddexp tens of millions of times on *scalars*, where numpy's ufunc
    dispatch overhead (~1.5us) dwarfs the two libm calls it performs. It
    mirrors numpy's C implementation branch-for-branch and calls the same
    libm `log1p`/`exp`, so it is bit-identical to `np.logaddexp` on every
    input, including +-inf and nan (see
    tests/test_partition_function.py::test_logaddexp_bit_identical_to_numpy).
    """
    if x == y:
        # Also the correct +-inf case: -inf + LOGE2 == -inf.
        return x + _LOGE2
    tmp = x - y
    if tmp > 0:
        return x + math.log1p(math.exp(-tmp))
    if tmp <= 0:
        return y + math.log1p(math.exp(tmp))
    return x + y  # nan propagation


def _logaddexp_reduce(zs):
    """Left fold matching `np.logaddexp.reduce` over a 1-D sequence."""
    acc = zs[0]
    for z in zs[1:]:
        acc = logaddexp(acc, z)
    return acc


def _role_dp(values, n_max, tau):
    """E_{r,k} for k=0..n_max: log sum over k-subsets of exp(sum v/tau)."""
    dp = [-math.inf] * (n_max + 1)
    dp[0] = 0.0
    for v in values:
        vt = v / tau
        for k in range(n_max, 0, -1):
            dp[k] = logaddexp(dp[k], dp[k - 1] + vt)
    return dp


def _n_max(patterns):
    return {r: max(p[0][i] for p in patterns)
            for i, r in enumerate(ROLE_ORDER)}


def role_values(v, roles):
    """Bucket a hero-indexed value Series into per-role value lists,
    preserving the Series' order within each role (the DP's accumulation
    order, and hence its exact floating-point result, depends on it)."""
    by_role = {r: [] for r in ROLE_ORDER}
    for h, val in v.items():
        by_role[roles[h]].append(val)
    return by_role


def comp_value_from_roles(by_role, tau, patterns=DEFAULT_PATTERNS, dp=None):
    """`soft_comp_value` given pre-bucketed per-role value lists.

    `dp` optionally supplies already-computed per-role DP tables. Callers
    that evaluate many single-hero deletions from one pool (see
    `soft_denial.denial_values`) reuse the two untouched roles' tables,
    which is exact: dropping a hero changes only its own role's list.
    """
    if dp is None:
        n_max = _n_max(patterns)
        dp = {r: _role_dp(by_role[r], n_max[r], tau) for r in ROLE_ORDER}
    zs = []
    for counts, rho in patterns:
        z = rho / tau
        feasible = True
        for i, r in enumerate(ROLE_ORDER):
            if counts[i] > len(by_role[r]):
                feasible = False
                break
            z += dp[r][counts[i]]
        if feasible and math.isfinite(z):
            zs.append(z)
    if not zs:
        return float("-inf")
    return tau * _logaddexp_reduce(zs)


def soft_comp_value(v, roles, tau, patterns=DEFAULT_PATTERNS):
    return comp_value_from_roles(role_values(v, roles), tau, patterns)


def brute_force_comp_value(v, roles, tau, patterns=DEFAULT_PATTERNS):
    by_role = {r: [h for h in v.index if roles[h] == r] for r in ROLE_ORDER}
    terms = []
    for counts, rho in patterns:
        pools = [itertools.combinations(by_role[r], counts[i])
                 for i, r in enumerate(ROLE_ORDER)]
        for combo in itertools.product(*pools):
            heroes = [h for grp in combo for h in grp]
            terms.append((v[heroes].sum() + rho) / tau)
    if not terms:
        return float("-inf")
    return tau * np.logaddexp.reduce(np.array(terms))
