"""Protect conditional logit with team latent preferences (section 8)."""
from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.optimize import minimize


def softplus(x):
    return np.logaddexp(0.0, x)


def inv_softplus(y):
    return y + np.log(-np.expm1(-y)) if y > 1e-8 else np.log(np.expm1(y))


@dataclass
class ProtectObs:
    team: str
    slot: str
    legal: tuple
    chosen: str
    alpha: pd.Series
    cap: pd.Series
    emb: pd.DataFrame


class ProtectModel:
    def fit(self, obs, d=3, sigma_eta=0.35, seed=0):
        teams = sorted({o.team for o in obs})
        t_index = {t: i for i, t in enumerate(teams)}
        # precompute numpy views per observation
        pre = []
        for o in obs:
            legal = list(o.legal)
            pre.append((
                t_index[o.team],
                o.alpha.reindex(legal).to_numpy(),
                o.cap.reindex(legal).to_numpy(),
                o.emb.reindex(legal).to_numpy(),
                legal.index(o.chosen),
            ))

        def unpack(theta):
            beta_p = softplus(theta[0])
            eta = theta[1:].reshape(len(teams), d)
            return beta_p, eta

        def objective(theta):
            beta_p, eta = unpack(theta)
            nll = 0.0
            for ti, alpha, cap, emb, yi in pre:
                u = alpha + beta_p * cap + emb @ eta[ti]
                nll += np.logaddexp.reduce(u) - u[yi]
            return nll + (eta ** 2).sum() / (2.0 * sigma_eta ** 2)

        theta0 = np.zeros(1 + len(teams) * d)
        res = minimize(objective, theta0, method="L-BFGS-B")
        beta_p, eta = unpack(res.x)
        self.beta_p = float(beta_p)
        self.d = d
        self.eta = {t: eta[i].copy() for t, i in t_index.items()}
        return self

    def _eta(self, team):
        return self.eta.get(team, np.zeros(self.d))

    def utilities(self, team, alpha, cap, emb):
        latent = pd.Series(emb.to_numpy() @ self._eta(team), index=emb.index)
        return alpha + self.beta_p * cap + latent

    def predict(self, team, alpha, cap, emb):
        u = self.utilities(team, alpha, cap, emb)
        p = np.exp(u - u.max())
        return p / p.sum()
