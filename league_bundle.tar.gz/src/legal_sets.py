"""Legal choice sets, spec Part II section 2."""
from src.draft_state import BLUE, RED


def _opponent(side):
    return RED if side == BLUE else BLUE


def legal_bans(state, side):
    """Ban by `side` targets the opponent's pool: exclude heroes already
    banned against the opponent (= banned BY `side`) and heroes the
    opponent protected."""
    opp = _opponent(side)
    return state.roster - set(state.bans_by[side]) - set(state.protects_by[opp])


def legal_protects(state, side):
    """Protect by `side`: exclude heroes banned against `side` (= banned
    BY the opponent) and heroes `side` already protected."""
    opp = _opponent(side)
    return state.roster - set(state.bans_by[opp]) - set(state.protects_by[side])
