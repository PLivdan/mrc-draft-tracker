"""Load processed map records into model-facing structures."""
import json
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from src.draft_state import PHASES, DraftState


@dataclass(frozen=True)
class Action:
    phase: int
    side: str
    kind: str
    slot: str
    hero: str


@dataclass
class MapData:
    map_uid: str
    match_id: str
    event_id: str
    played_at: int
    teams: dict
    lineups: dict
    hero_time: dict
    actions: list
    roster: frozenset
    winner_side: str


def load_dataset(processed_dir="data/processed", rosters_dir="data/patch_rosters"):
    processed = Path(processed_dir)
    rosters = {}
    for p in Path(rosters_dir).glob("*.json"):
        info = json.loads(p.read_text())
        rosters[info["event_id"]] = frozenset(info["heroes"])
    maps = []
    index = json.loads((processed / "index.json").read_text())
    for row in index:
        if row["qa_status"] != "pass":
            continue
        rec = json.loads(
            (processed / "maps" /
             f"{row['map_uid'].replace(':', '_')}.json").read_text()
        )
        event_id = rec["event_id"]
        if event_id not in rosters:
            raise ValueError(f"no roster file for event {event_id} (map {rec['map_uid']})")
        maps.append(MapData(
            map_uid=rec["map_uid"],
            match_id=rec["match_id"],
            event_id=event_id,
            played_at=rec["played_at"],
            teams={s: t["name"] for s, t in rec["teams"].items()},
            lineups={s: [p["player_id"] for p in ps]
                     for s, ps in rec["lineups"].items()},
            hero_time=rec["hero_time"],
            actions=[Action(**a) for a in rec["actions"]],
            roster=rosters[event_id],
            winner_side=rec["winner_side"],
        ))
    maps.sort(key=lambda m: (m.played_at or 0, m.map_uid))
    return maps


def _usage(maps, row_key):
    rows = {}
    for m in maps:
        for side in ("blue", "red"):
            for pid in m.lineups[side]:
                heroes = set(m.hero_time.get(pid, {}))
                key_owner = m.teams[side] if row_key == "team" else pid
                row = rows.setdefault((key_owner, m.map_uid), set())
                row |= heroes
    all_heroes = sorted(set().union(*rows.values())) if rows else []
    if not rows:
        df = pd.DataFrame(0, index=pd.MultiIndex.from_arrays([[], []]),
                          columns=all_heroes, dtype=int)
    else:
        df = pd.DataFrame(0, index=pd.MultiIndex.from_tuples(sorted(rows)),
                          columns=all_heroes, dtype=int)
        for key, heroes in rows.items():
            df.loc[key, sorted(heroes)] = 1
    return df


def team_map_usage(maps):
    return _usage(maps, "team")


def player_map_usage(maps):
    return _usage(maps, "player")


def replay_decisions(map_data):
    state = DraftState(roster=map_data.roster)
    by_phase = {}
    for a in map_data.actions:
        by_phase.setdefault(a.phase, {})[a.side] = a
    pairs = []
    for phase, slots in PHASES:
        acts = by_phase[phase]
        for slot in slots:
            pairs.append((state, acts[slot.side]))
        state = state.apply_phase(
            phase, {side: a.hero for side, a in acts.items()}
        )
    return pairs


def series_of(maps):
    groups = {}
    for m in maps:
        groups.setdefault(m.match_id, []).append(m)
    return sorted(groups.values(), key=lambda g: (g[0].played_at or 0))
