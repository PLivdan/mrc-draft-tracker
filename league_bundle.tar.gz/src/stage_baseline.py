"""Stage-specific empirical baselines with kind-level shrinkage (section 7)."""
import numpy as np
import pandas as pd

SLOTS = {"ban": ["B1", "B2", "B3", "B4"], "protect": ["P1", "P2"]}


def slot_baselines(actions, roster, kappa_s=4.0, pseudo=0.25):
    roster = sorted(roster)
    out = {}
    for kind, slots in SLOTS.items():
        kind_counts = pd.Series(0.0, index=roster)
        slot_counts = {s: pd.Series(0.0, index=roster) for s in slots}
        for a in actions:
            if a.kind != kind or a.hero not in kind_counts.index:
                continue
            kind_counts[a.hero] += 1
            slot_counts[a.slot][a.hero] += 1
        p_a = (kind_counts + pseudo) / (kind_counts + pseudo).sum()
        for s in slots:
            n_s = slot_counts[s].sum()
            p_s = (slot_counts[s] + kappa_s * p_a) / (n_s + kappa_s)
            out[s] = np.log(p_s)
    return out
