"""Extract per-map draft records from archived mrvl.net pages."""
from src.canonicalize import canonical_hero, canonical_player, canonical_team, \
    load_overrides
from src.draft_state import BLUE, RED, SLOT_OF
from src.tsr_parser import find_query, parse_tsr

CAMP_SIDE = {1: BLUE, 0: RED}


def extract_event(html):
    data = find_query(parse_tsr(html), "events:getOverviewData")
    if data is None:
        raise ValueError("no events:getOverviewData payload in page")
    event = data["event"]
    ids, stack, seen = [], [data], set()
    while stack:
        n = stack.pop()
        if id(n) in seen:
            continue
        seen.add(id(n))
        if isinstance(n, dict):
            mid = n.get("matchId")
            if isinstance(mid, str) and mid.startswith("js7") and mid not in ids:
                ids.append(mid)
            # Group-stage events (round-robin "Standings" groups) reference
            # their matches via a plural "matchIds" list instead of the
            # singular per-node "matchId" used by bracket views.
            for mid2 in n.get("matchIds") or []:
                if isinstance(mid2, str) and mid2.startswith("js7") and mid2 not in ids:
                    ids.append(mid2)
            stack.extend(n.values())
        elif isinstance(n, list):
            stack.extend(n)
    return {"event_id": event["id"], "event_name": event["name"],
            "match_ids": sorted(ids)}


def _resolve_team(short_or_name, linked_team_id, match):
    """Map a scoreboard team to the match-level team id/name."""
    # First try direct linkedTeamId match
    if linked_team_id:
        if linked_team_id == match.get("teamOneId"):
            return match.get("teamOneId"), match.get("teamOneName")
        if linked_team_id == match.get("teamTwoId"):
            return match.get("teamTwoId"), match.get("teamTwoName")
    # Fall back to name-based matching
    one = (match.get("teamOneName") or "", match.get("teamOneId"))
    two = (match.get("teamTwoName") or "", match.get("teamTwoId"))
    for name, tid in (one, two):
        if short_or_name and short_or_name == name:
            return tid, name
    for name, tid in (one, two):
        if short_or_name and short_or_name.lower() in name.lower():
            return tid, name
    raise ValueError(f"cannot resolve team {short_or_name!r} in match "
                     f"{match.get('id')}")


def extract_map_records(html, match_id, overrides):
    data = find_query(parse_tsr(html), "matches:getPageData")
    if data is None:
        raise ValueError(f"no matches:getPageData payload for {match_id}")
    match = data["match"]
    event = data.get("event") or {}
    records = []
    for game in match.get("games") or []:
        sb = game.get("scoreboard")
        if not sb:
            continue
        teams_by_side, lineups, hero_time, actions, scores = {}, {}, {}, [], {}
        # Build mapping of player ID to role for this game
        role_by_pid = {p["playerId"]: p["role"] for p in game.get("players") or []}
        for team in sb["teams"]:
            camps = {a["teamCamp"]
                     for a in (team.get("bans") or []) + (team.get("protects") or [])}
            if len(camps) != 1:
                raise ValueError(f"ambiguous camp for {team.get('shortName')} "
                                 f"in {match_id} g{game.get('gameNumber')}")
            side = CAMP_SIDE[camps.pop()]
            short = team.get("shortName") or ""
            tid, name = _resolve_team(short or team.get("name"), team.get("linkedTeamId"), match)
            teams_by_side[side] = {
                "team_id": tid,
                "name": canonical_team(name, overrides),
                "short": short,
            }
            scores[side] = team.get("score")
            for action in (team.get("bans") or []) + (team.get("protects") or []):
                phase = action["phaseIndex"]
                kind = action["kind"]
                actions.append({
                    "phase": phase,
                    "side": side,
                    "kind": kind,
                    "slot": SLOT_OF.get((side, kind, phase)),
                    "hero": canonical_hero(action["hero"]["id"], overrides),
                })
            side_lineup = []
            for pl in team.get("players") or []:
                pid = canonical_player(
                    pl.get("linkedPlayerId") or pl.get("name"), overrides
                )
                side_lineup.append({
                    "player_id": pid,
                    "name": pl.get("name"),
                    "role": role_by_pid.get(pid),
                })
                shares = {}
                for hp in pl.get("heroesPlayed") or []:
                    slug = canonical_hero(hp["hero"]["id"], overrides)
                    shares[slug] = shares.get(slug, 0.0) + float(
                        hp.get("playTimeSeconds") or 0.0
                    )
                hero_time[pid] = shares
            lineups[side] = side_lineup
        actions.sort(key=lambda a: (a["phase"], a["side"]))
        winner = None
        if scores.get(BLUE) is not None and scores.get(RED) is not None:
            if scores[BLUE] > scores[RED]:
                winner = BLUE
            elif scores[RED] > scores[BLUE]:
                winner = RED
        records.append({
            "map_uid": f"{match_id}:g{game['gameNumber']}",
            "match_id": match_id,
            "event_id": match.get("eventId") or event.get("id"),
            "event_name": event.get("name"),
            "played_at": sb.get("playedAt"),
            "map_slug": (sb.get("map") or {}).get("slug") or game.get("map"),
            "map_name": (sb.get("map") or {}).get("name"),
            "mode": None,
            "replay_id": game.get("replayId"),
            "teams": teams_by_side,
            "actions": actions,
            "lineups": lineups,
            "hero_time": hero_time,
            "winner_side": winner,
            "qa": None,
        })
    records.sort(key=lambda r: (r["played_at"] or 0, r["map_uid"]))
    return records


import argparse
import json
import time
from pathlib import Path

import requests

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36")
RAW = Path("data/raw")
PROCESSED = Path("data/processed/maps")


def _get(url, session):
    resp = session.get(url, headers={"User-Agent": UA}, timeout=30)
    resp.raise_for_status()
    time.sleep(1.5)
    return resp.text


def cmd_fetch():
    events = json.loads(Path("data/events.json").read_text())
    session = requests.Session()
    (RAW / "events").mkdir(parents=True, exist_ok=True)
    (RAW / "matches").mkdir(parents=True, exist_ok=True)
    for ev in events:
        ev_path = RAW / "events" / f"{ev['event_id']}.html"
        if not ev_path.exists():
            print(f"fetch event {ev['name']}")
            ev_path.write_text(_get(ev["url"], session))
        parsed = extract_event(ev_path.read_text())
        for mid in parsed["match_ids"]:
            m_path = RAW / "matches" / f"{mid}.html"
            if m_path.exists():
                continue
            print(f"fetch match {mid}")
            m_path.write_text(_get(f"https://mrvl.net/matches/{mid}", session))


def cmd_build():
    from src.qa import validate_map

    overrides = load_overrides()
    PROCESSED.mkdir(parents=True, exist_ok=True)
    index, report_lines = [], []
    for ev_path in sorted((RAW / "events").glob("*.html")):
        parsed = extract_event(ev_path.read_text())
        roster_path = Path("data/patch_rosters") / f"{parsed['event_id']}.json"
        if not roster_path.exists():
            raise SystemExit(f"missing roster file {roster_path}")
        roster_info = json.loads(roster_path.read_text())
        if not roster_info.get("verified"):
            raise SystemExit(f"roster {roster_path} is not hand-verified")
        roster = set(roster_info["heroes"])
        for mid in parsed["match_ids"]:
            m_path = RAW / "matches" / f"{mid}.html"
            if not m_path.exists():
                report_lines.append(f"- MISSING raw page for match {mid}")
                continue
            try:
                records = extract_map_records(m_path.read_text(), mid, overrides)
            except ValueError as exc:
                report_lines.append(f"- EXTRACTION FAILED {mid}: {exc}")
                continue
            for rec in records:
                rec["qa"] = validate_map(rec, roster)
                out = PROCESSED / f"{rec['map_uid'].replace(':', '_')}.json"
                out.write_text(json.dumps(rec, indent=1))
                index.append({
                    "map_uid": rec["map_uid"],
                    "played_at": rec["played_at"],
                    "event_id": rec["event_id"],
                    "qa_status": rec["qa"]["status"],
                })
                if rec["qa"]["status"] != "pass":
                    report_lines.append(
                        f"- REJECT {rec['map_uid']}: {rec['qa']['violations']}"
                    )
    index.sort(key=lambda r: (r["played_at"] or 0, r["map_uid"]))
    Path("data/processed/index.json").write_text(json.dumps(index, indent=1))
    n_pass = sum(1 for r in index if r["qa_status"] == "pass")
    Path("outputs/tables").mkdir(parents=True, exist_ok=True)
    Path("outputs/tables/qa_report.md").write_text(
        f"# QA report\n\n{n_pass}/{len(index)} maps pass.\n\n"
        + "\n".join(report_lines) + "\n"
    )
    print(f"{n_pass}/{len(index)} maps pass QA")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["fetch", "build"])
    args = ap.parse_args()
    cmd_fetch() if args.command == "fetch" else cmd_build()
