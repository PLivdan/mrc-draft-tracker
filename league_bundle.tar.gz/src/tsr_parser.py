"""Parser for mrvl.net's server-rendered TSR router payload.

The page embeds one script containing
    $_TSR.router=($R=>$R[0]={...})($R["tsr"]);
where {...} is a JS object-literal expression with inline `$R[n]=`
assignments, bare `$R[n]` back-references, `!0`/`!1` booleans and
occasional opaque values (arrow functions), which we skip as None.
"""
import json
import re


def parse_tsr(text):
    m = re.search(r"\$_TSR\.router=\(\$R=>", text)
    if m is None:
        raise ValueError("no TSR router payload found in page")
    refs = {}

    def skip_ws(p):
        while text[p] in " \n\t\r":
            p += 1
        return p

    def parse_string(p):
        q = p + 1
        while True:
            if text[q] == "\\":
                q += 2
                continue
            if text[q] == '"':
                break
            q += 1
        raw = text[p:q + 1]
        # JS string literals allow \xHH hex escapes (seen in mrvl.net's
        # liquipediaBracketId field, e.g. "\x3C!-- comment -->"); JSON does
        # not, so promote them to the equivalent \u00HH before decoding.
        raw = re.sub(r"\\x([0-9A-Fa-f]{2})", r"\\u00\1", raw)
        return json.loads(raw, strict=False), q + 1

    def skip_opaque(p):
        depth = 0
        while True:
            c = text[p]
            if c in "\"'`":
                quote = c
                p += 1
                while text[p] != quote:
                    p += 2 if text[p] == "\\" else 1
                p += 1
                continue
            if c in "({[":
                depth += 1
            elif c in ")}]":
                if depth == 0:
                    return None, p
                depth -= 1
            elif c == "," and depth == 0:
                return None, p
            p += 1

    def parse(p):
        p = skip_ws(p)
        c = text[p]
        if text.startswith("$R[", p):
            q = text.index("]", p)
            n = int(text[p + 3:q])
            p2 = q + 1
            if text[p2] == "=" and text[p2 + 1] != "=":
                val, p3 = parse(p2 + 1)
                refs[n] = val
                return val, p3
            # Check if next character is a valid delimiter
            if text[p2] not in ",}] \n\t\r":
                return skip_opaque(p)  # Treat as opaque, not a bare reference
            return refs.get(n), p2
        if c == "{":
            obj = {}
            p = skip_ws(p + 1)
            if text[p] == "}":
                return obj, p + 1
            while True:
                p = skip_ws(p)
                if text[p] == '"':
                    key, p = parse_string(p)
                else:
                    q = text.index(":", p)
                    key = text[p:q].strip()
                    p = q
                p = skip_ws(p)
                val, p = parse(p + 1)
                obj[key] = val
                p = skip_ws(p)
                if text[p] == ",":
                    p += 1
                    continue
                return obj, p + 1
        if c == "[":
            arr = []
            p = skip_ws(p + 1)
            if text[p] == "]":
                return arr, p + 1
            while True:
                val, p = parse(p)
                arr.append(val)
                p = skip_ws(p)
                if text[p] == ",":
                    p += 1
                    continue
                return arr, p + 1
        if c == '"':
            return parse_string(p)
        for lit, v, ln in (
            ("!0", True, 2), ("!1", False, 2), ("null", None, 4),
            ("void 0", None, 6), ("undefined", None, 9),
            ("-Infinity", float("-inf"), 9), ("Infinity", float("inf"), 8),
            ("NaN", float("nan"), 3),
        ):
            if text.startswith(lit, p):
                return v, p + ln
        m2 = re.match(r"-?\d+(\.\d+)?([eE][+-]?\d+)?", text[p:p + 40])
        if m2:
            tok = m2.group(0)
            if text[p + len(tok)] not in ",}] \n\t\r":
                return skip_opaque(p)  # e.g. `1e3.foo(...)` — not a bare number
            val = float(tok) if any(ch in tok for ch in ".eE") else int(tok)
            return val, p + len(tok)
        return skip_opaque(p)

    val, _ = parse(m.end())
    return val


def find_query(root, name):
    """Find the Convex query result `_valueJSON` with `_name == name`."""
    stack = [root]
    seen = set()
    while stack:
        n = stack.pop()
        if id(n) in seen:
            continue
        seen.add(id(n))
        if isinstance(n, dict):
            if n.get("_name") == name and "_valueJSON" in n:
                return n["_valueJSON"]
            stack.extend(n.values())
        elif isinstance(n, list):
            stack.extend(n)
    return None
