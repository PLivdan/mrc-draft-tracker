"""Global hero prevalence (section 5) and team capability (section 6)."""
import numpy as np
import pandas as pd


def global_prior(usage, roster, alpha=0.5):
    roster = sorted(roster)
    counts = usage.reindex(columns=roster, fill_value=0).sum(axis=0)
    n_rows = len(usage)
    return (counts + alpha) / (n_rows + alpha * len(roster))


def team_capability(usage, team, roster, g, delta=0.88, kappa=3.0):
    g = g.reindex(sorted(roster))
    if team in usage.index.get_level_values(0):
        rows = usage.loc[team].reindex(columns=g.index, fill_value=0)
        K = len(rows)
        # most recent past map (last row) gets weight delta**1
        w = delta ** np.arange(K, 0, -1)
        n_ih = pd.Series(w @ rows.to_numpy(dtype=float), index=g.index)
        n_i = w.sum()
    else:
        n_ih = pd.Series(0.0, index=g.index)
        n_i = 0.0
    return (n_ih + kappa * g) / (n_i + kappa)
