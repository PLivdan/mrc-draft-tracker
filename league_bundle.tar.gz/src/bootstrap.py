"""Map-cluster bootstrap for model comparisons (section 18)."""
import numpy as np


def map_cluster_bootstrap(results, model_a, model_b, metric="top3",
                          n=10000, seed=0):
    rng = np.random.default_rng(seed)
    a = results[results["model"] == model_a].groupby("map_uid")[metric].mean()
    b = results[results["model"] == model_b].groupby("map_uid")[metric].mean()
    maps = a.index.intersection(b.index).to_list()
    av, bv = a[maps].to_numpy(), b[maps].to_numpy()
    delta = bv.mean() - av.mean()
    idx = rng.integers(0, len(maps), size=(n, len(maps)))
    deltas = bv[idx].mean(axis=1) - av[idx].mean(axis=1)
    return {"delta": float(delta),
            "ci_low": float(np.percentile(deltas, 2.5)),
            "ci_high": float(np.percentile(deltas, 97.5)),
            "n_maps": len(maps)}
