"""Ban conditional logit with stage-specific shrunk coefficients (section 14)."""
from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.optimize import minimize

from src.protect_model import softplus

SLOTS = ("B1", "B2", "B3", "B4")


@dataclass
class BanObs:
    slot: str
    legal: tuple
    chosen: str
    alpha: pd.Series
    cap_opp: pd.Series
    denial: pd.Series


class BanModel:
    def fit(self, obs, use_denial=True, stage_specific=True,
            penalties=(0.08, 0.10, 0.45, 0.45)):
        p_b, p_k, p_bbar, p_kbar = penalties
        pre = []
        for o in obs:
            legal = list(o.legal)
            pre.append((
                SLOTS.index(o.slot),
                o.alpha.reindex(legal).to_numpy(),
                o.cap_opp.reindex(legal).to_numpy(),
                o.denial.reindex(legal).to_numpy(),
                legal.index(o.chosen),
            ))
        n_b = 4 if stage_specific else 1
        n_k = (4 if stage_specific else 1) if use_denial else 0

        def unpack(theta):
            beta = softplus(theta[:n_b])
            if stage_specific:
                betas = beta
            else:
                betas = np.repeat(beta, 4)
            if not use_denial:
                kappas = np.zeros(4)
            elif stage_specific:
                kappas = softplus(theta[n_b:n_b + n_k])
            else:
                kappas = np.repeat(softplus(theta[n_b:n_b + n_k]), 4)
            return betas, kappas

        def objective(theta):
            betas, kappas = unpack(theta)
            nll = 0.0
            for si, alpha, cap, den, yi in pre:
                u = alpha + betas[si] * cap + kappas[si] * den
                nll += np.logaddexp.reduce(u) - u[yi]
            pen = p_b * (betas ** 2).sum() + p_k * (kappas ** 2).sum()
            pen += p_bbar * ((betas - betas.mean()) ** 2).sum()
            pen += p_kbar * ((kappas - kappas.mean()) ** 2).sum()
            return nll + pen

        theta0 = np.zeros(n_b + n_k)
        res = minimize(objective, theta0, method="L-BFGS-B")
        betas, kappas = unpack(res.x)
        self.beta = dict(zip(SLOTS, betas.tolist()))
        self.kappa = dict(zip(SLOTS, kappas.tolist()))
        return self

    def utilities(self, o):
        return (o.alpha + self.beta[o.slot] * o.cap_opp
                + self.kappa[o.slot] * o.denial)

    def predict(self, o):
        u = self.utilities(o)
        p = np.exp(u - u.max())
        return p / p.sum()
