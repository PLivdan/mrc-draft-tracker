"""League-wide Ignite 2026 ladder (spec sections 15, 17, 18, 24).

Same protocol as `run_replication` but over every event in the dataset
rather than the Mid-Season Finals subset, with tau re-selected on the first
`N_TAU_SELECT` held-out series and those series then excluded from every
reported table (so nothing tau touched is also scored).

The evaluation is a chronological leave-series-out sweep over ~314 series
whose per-series cost grows with the training prefix, i.e. tens of CPU-hours
sequentially, so it runs through `evaluate_parallel`. That is a row-for-row
drop-in for `evaluate` (see tests/test_evaluation.py) -- the parallelism buys
wall-clock only and changes no number in the tables below.
"""
import os

# Must precede the numpy/scipy import chain: each worker process is already a
# full core's worth of work, so letting OpenBLAS also fan out inside them just
# oversubscribes the machine. Explicit caller settings win.
for _v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ.setdefault(_v, "1")

import json  # noqa: E402
import time  # noqa: E402
from collections import Counter  # noqa: E402
from pathlib import Path  # noqa: E402

import pandas as pd  # noqa: E402

from src.bootstrap import map_cluster_bootstrap  # noqa: E402
from src.dataset import load_dataset, series_of  # noqa: E402
from src.evaluation import (  # noqa: E402
    LADDER, LadderModel, evaluate_parallel, fit_shared, metrics_table,
    per_slot_table, select_tau,
)

N_WARM = 3
N_TAU_SELECT = 3
N_WORKERS = int(os.environ.get("LEAGUE_WORKERS", "4"))
OUT_PATH = Path("outputs/tables/league_ladder.md")
CACHE_PATH = Path("outputs/league_results.csv.gz")
# Per-series checkpoints: this sweep runs for hours on a shared machine, so
# an interrupted run resumes instead of restarting. Safe to delete.
CKPT_DIR = Path("outputs/.league_ckpt")


def _fmt_coefs(d):
    return ", ".join(f"{k}={v:.4f}" for k, v in sorted(d.items()))


def _event_names():
    return {e["event_id"]: e["name"]
            for e in json.loads(Path("data/events.json").read_text())}


def _qa_counts():
    """Per-event (n_pass, n_total) from the processed index, so the report
    can flag any event that is mostly QA rejects."""
    idx = json.loads(Path("data/processed/index.json").read_text())
    total = Counter(r["event_id"] for r in idx)
    passed = Counter(r["event_id"] for r in idx if r["qa_status"] == "pass")
    return passed, total


def main():
    t_start = time.perf_counter()
    roles = json.loads(Path("data/roles/heroes.json").read_text())
    maps = load_dataset()
    groups = series_of(maps)
    print(f"{len(maps)} maps in {len(groups)} series", flush=True)

    tau = select_tau(maps, n_selection_series=N_TAU_SELECT,
                     n_warm_series=N_WARM, roles=roles)
    print(f"selected tau = {tau}", flush=True)

    models = {name: LadderModel(name, tau=tau, roles=roles)
              for name in LADDER}
    t0 = time.perf_counter()
    if CACHE_PATH.exists() and os.environ.get("LEAGUE_USE_CACHE"):
        print(f"reusing cached results from {CACHE_PATH}", flush=True)
        results = pd.read_csv(CACHE_PATH)
    else:
        results = evaluate_parallel(models, maps, n_warm_series=N_WARM,
                                    n_workers=N_WORKERS,
                                    checkpoint_dir=CKPT_DIR)
        CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        results.to_csv(CACHE_PATH, index=False)
    t_eval = time.perf_counter() - t0
    print(f"evaluate_parallel: {t_eval / 60:.1f} min, {len(results)} rows",
          flush=True)

    # Drop the tau-selection window: only series after it are reported.
    report_series = {g[0].match_id for g in groups[N_WARM + N_TAU_SELECT:]}
    rep = results[results["series"].isin(report_series)].copy()

    # Final refit at the largest training prefix -- the same fit the last
    # held-out series used -- for the reported ban coefficients.
    t0 = time.perf_counter()
    final_train = [m for g in groups[:-1] for m in g]
    shared = fit_shared(final_train, roles=roles)
    m4 = LadderModel("M4", tau=tau, roles=roles).fit(final_train,
                                                     shared=shared)
    print(f"final refit: {(time.perf_counter() - t0) / 60:.1f} min",
          flush=True)

    event_of = {m.map_uid: m.event_id for m in maps}
    rep["event"] = rep["map_uid"].map(event_of)
    names, (passed, total) = _event_names(), _qa_counts()
    # chronological event order for the breakdown table
    first_seen = {}
    for m in maps:
        first_seen.setdefault(m.event_id, m.played_at)
        first_seen[m.event_id] = min(first_seen[m.event_id], m.played_at)

    first, last = min(m.played_at for m in maps), max(m.played_at for m in maps)
    span = (f"{pd.to_datetime(first, unit='s'):%Y-%m-%d} to "
            f"{pd.to_datetime(last, unit='s'):%Y-%m-%d}")

    out = [
        "# League-wide Ignite 2026 ladder\n",
        f"Chronological leave-series-out over all {len(groups)} series "
        f"({len(maps)} QA-passing maps, {len(first_seen)} "
        f"events), sample {span}. First {N_WARM} series are warm-up; "
        f"tau selected on the next {N_TAU_SELECT} held-out series and those "
        f"excluded from every table below.\n",
        f"tau = **{tau}**\n",
        f"reported: {len(report_series)} held-out series, "
        f"{rep['map_uid'].nunique()} maps, {len(rep) // len(LADDER)} "
        f"decisions per model\n",
        "## Ladder (all reported held-out decisions)\n",
        metrics_table(rep).to_markdown(), "\n",
        "## Per-slot\n", per_slot_table(rep).to_markdown(), "\n",
        "## Bootstrap comparisons (map-cluster, 10k resamples)\n",
        "| comparison | metric | delta | 95% CI | n maps |",
        "|---|---|---|---|---|",
    ]
    for a, b in (("M0", "M4"), ("M3", "M4")):
        for metric in ("top3", "logloss"):
            bt = map_cluster_bootstrap(rep, a, b, metric=metric)
            out.append(
                f"| {b} vs {a} | {metric} | {bt['delta']:+.4f} | "
                f"[{bt['ci_low']:+.4f}, {bt['ci_high']:+.4f}] | "
                f"{bt['n_maps']} |"
            )
    out.append("")

    out.append("## Per-event breakdown (M0 vs M4)\n")
    out.append("| event | maps | QA pass | M0 Top3 | M4 Top3 | M0 LogLoss "
               "| M4 LogLoss |")
    out.append("|---|---|---|---|---|---|---|")
    for ev in sorted(rep["event"].unique(), key=lambda e: first_seen[e]):
        sub = rep[rep["event"] == ev]
        t = metrics_table(sub)
        n_p, n_t = passed[ev], total[ev]
        out.append(
            f"| {names.get(ev, ev)} | {sub['map_uid'].nunique()} | "
            f"{n_p}/{n_t} ({n_p / n_t:.0%}) | "
            f"{t.loc['M0', 'Top3']:.3f} | {t.loc['M4', 'Top3']:.3f} | "
            f"{t.loc['M0', 'LogLoss']:.3f} | {t.loc['M4', 'LogLoss']:.3f} |"
        )
    worst = min(total, key=lambda e: passed[e] / total[e])
    out.append(f"\nLowest QA pass rate: {names.get(worst, worst)} at "
               f"{passed[worst] / total[worst]:.0%}; no event is majority "
               f"rejects.\n")

    out.append("## Final-refit ban coefficients (M4, "
               f"trained on series 0..{len(groups) - 2})\n")
    out.append(f"- beta: {_fmt_coefs(m4.ban.beta)}")
    out.append(f"- kappa: {_fmt_coefs(m4.ban.kappa)}\n")

    runtime = (time.perf_counter() - t_start) / 60
    out.append(f"_Total runtime {runtime:.1f} min "
               f"({N_WORKERS} worker processes)._\n")

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUT_PATH.write_text("\n".join(out))
    print(f"wrote {OUT_PATH} (total {runtime:.1f} min)", flush=True)


if __name__ == "__main__":
    main()
