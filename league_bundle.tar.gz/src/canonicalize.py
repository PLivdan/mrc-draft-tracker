"""Canonical identities for heroes, teams, players (QA rules 9-10).

Manual corrections live in data/overrides.json, never in code.
"""
import json
from pathlib import Path

DEFAULT_PATH = Path("data/overrides.json")


def load_overrides(path=DEFAULT_PATH):
    p = Path(path)
    if not p.exists():
        return {"hero_aliases": {}, "team_aliases": {}, "player_aliases": {}}
    ovr = json.loads(p.read_text())
    for key in ("hero_aliases", "team_aliases", "player_aliases"):
        ovr.setdefault(key, {})
    return ovr


def canonical_hero(slug, overrides):
    s = slug.strip().lower()
    return overrides["hero_aliases"].get(s, s)


def canonical_team(name, overrides):
    s = name.strip()
    return overrides["team_aliases"].get(s, s)


def canonical_player(player_id, overrides):
    s = player_id.strip()
    return overrides["player_aliases"].get(s, s)
