"""Replicate the pilot ladder on the Mid-Season Finals subset (spec
Part II sections 15, 17, 18; Part I section 6 defines the target)."""
import json
from pathlib import Path

from src.bootstrap import map_cluster_bootstrap
from src.dataset import load_dataset, series_of
from src.evaluation import LadderModel, evaluate, metrics_table, \
    per_slot_table, select_tau

MSF_EVENT_ID = "jd7fnf7yebjv9kw0j0rrans2058bfdke"


def main():
    roles = json.loads(Path("data/roles/heroes.json").read_text())
    maps = [m for m in load_dataset() if m.event_id == MSF_EVENT_ID]
    print(f"{len(maps)} MSF maps in {len(series_of(maps))} series")
    tau = select_tau(maps, n_selection_series=3, n_warm_series=1,
                     roles=roles)
    print(f"selected tau = {tau}")
    models = {name: LadderModel(name, tau=tau, roles=roles)
              for name in ("M0", "M1", "M2", "M3", "M4")}
    results = evaluate(models, maps, n_warm_series=1)
    # report ONLY the final series (the Grand Final) for the section-17
    # comparison, plus all-heldout tables for context
    last_series = series_of(maps)[-1][0].match_id
    gf = results[results["series"] == last_series]
    boot = map_cluster_bootstrap(gf, "M0", "M4", metric="top3")
    out = ["# MSF replication\n",
           f"tau selected on first 3 held-out series: **{tau}**\n",
           "## Grand Final held-out ladder (pilot section-17 analogue)\n",
           metrics_table(gf).to_markdown(), "\n",
           "## Grand Final per-slot\n", per_slot_table(gf).to_markdown(),
           "\n", "## All held-out series\n",
           metrics_table(results).to_markdown(), "\n",
           f"## Bootstrap M4 vs M0 Top3 (GF maps): delta={boot['delta']:.3f} "
           f"CI=[{boot['ci_low']:.3f}, {boot['ci_high']:.3f}] "
           f"(n={boot['n_maps']} maps)\n"]
    Path("outputs/tables/replication_msf.md").write_text("\n".join(out))
    print("wrote outputs/tables/replication_msf.md")


if __name__ == "__main__":
    main()
