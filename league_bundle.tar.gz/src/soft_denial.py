"""Composition preference score, calibration and soft denial (sections 9, 13)."""
import numpy as np
import pandas as pd
from scipy.optimize import minimize

from src.composition_partition import (
    DEFAULT_PATTERNS, ROLE_ORDER, _n_max, _role_dp, comp_value_from_roles,
)


def revealed_score(g, cap, emb, eta, beta_p):
    return np.log(g) + beta_p * cap + pd.Series(
        emb.to_numpy() @ eta, index=emb.index
    )


def fit_lambda_r(y, r_scores):
    xs, ys = [], []
    for (team, _map), row in y.iterrows():
        r = r_scores.get(team)
        if r is None:
            continue
        common = row.index.intersection(r.index)
        xs.append(r[common].to_numpy())
        ys.append(row[common].to_numpy(dtype=float))
    x = np.concatenate(xs)
    t = np.concatenate(ys)

    def nll(theta):
        z = theta[0] + theta[1] * x
        return np.sum(np.logaddexp(0.0, z) - t * z)

    res = minimize(nll, np.zeros(2), method="L-BFGS-B")
    return float(res.x[0]), float(res.x[1])


def denial_values(v, roles, pool, tau, patterns=DEFAULT_PATTERNS):
    """Marginal composition value each hero in `pool` carries for its owner.

    Semantically this is `full - soft_comp_value(v_pool.drop(h))` for every
    h, exactly as written in section 13. It is implemented without ever
    materialising the |pool| dropped Series because this is by far the
    hottest loop in the league-scale evaluation: bucketing the pool by role
    once and splicing one element out of a plain Python list preserves the
    DP's accumulation order exactly, and dropping a hero leaves the other
    two roles' DP tables untouched so they are computed once and reused.
    Both shortcuts are bit-exact, not approximations -- see
    tests/test_soft_denial.py::test_denial_values_matches_naive_definition.
    """
    pool = sorted(pool)
    v_pool = v.reindex(pool)
    n_max = _n_max(patterns)

    # Per-role value lists in pool order, plus each hero's (role, position
    # within that role's list) so a deletion is a list splice.
    by_role = {r: [] for r in ROLE_ORDER}
    where = []
    for h, val in zip(pool, v_pool.to_numpy().tolist()):
        r = roles[h]
        where.append((r, len(by_role[r])))
        by_role[r].append(val)

    dp_full = {r: _role_dp(by_role[r], n_max[r], tau) for r in ROLE_ORDER}
    full = comp_value_from_roles(by_role, tau, patterns, dp=dp_full)
    if not np.isfinite(full):
        return pd.Series(0.0, index=pool)
    d = {}
    for h, (r, j) in zip(pool, where):
        sub_vals = by_role[r][:j] + by_role[r][j + 1:]
        sub_by_role = dict(by_role, **{r: sub_vals})
        sub_dp = dict(dp_full, **{r: _role_dp(sub_vals, n_max[r], tau)})
        sub = comp_value_from_roles(sub_by_role, tau, patterns, dp=sub_dp)
        d[h] = full - sub  # inf when removing h breaks feasibility
    out = pd.Series(d)
    finite = out[np.isfinite(out)]
    cap_val = finite.max() if len(finite) else 0.0
    out[~np.isfinite(out)] = cap_val
    return out.clip(lower=0.0)
