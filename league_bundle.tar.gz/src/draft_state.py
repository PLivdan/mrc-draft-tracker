"""MRC draft mechanism: stages, slots, state (spec Part II section 2)."""
from dataclasses import dataclass

BLUE = "blue"
RED = "red"
BAN = "ban"
PROTECT = "protect"


@dataclass(frozen=True)
class SlotRef:
    side: str
    kind: str
    number: int  # 1-based within kind

    @property
    def label(self) -> str:
        return f"{'B' if self.kind == BAN else 'P'}{self.number}"


# phaseIndex timeline as encoded by mrvl.net, verified against the
# NAVI-TLC Grand Final fixture. Phases 0 and 5 are the simultaneous ban
# stages (spec stages 1 and 5); camp 1 = Blue, camp 0 = Red.
PHASES = [
    (0, [SlotRef(BLUE, BAN, 1), SlotRef(RED, BAN, 1)]),   # stage 1 (simultaneous)
    (1, [SlotRef(RED, PROTECT, 1)]),                       # stage 2
    (2, [SlotRef(BLUE, BAN, 2)]),                          # stage 3 (ban)
    (3, [SlotRef(BLUE, PROTECT, 1)]),                      # stage 3 (protect)
    (4, [SlotRef(RED, BAN, 2)]),                           # stage 4
    (5, [SlotRef(BLUE, BAN, 3), SlotRef(RED, BAN, 3)]),   # stage 5 (simultaneous)
    (6, [SlotRef(BLUE, PROTECT, 2)]),                      # stage 6
    (7, [SlotRef(RED, BAN, 4)]),                           # stage 7 (ban)
    (8, [SlotRef(RED, PROTECT, 2)]),                       # stage 7 (protect)
    (9, [SlotRef(BLUE, BAN, 4)]),                          # stage 8
]

SIMULTANEOUS_PHASES = {0, 5}

SLOT_OF = {
    (slot.side, slot.kind, phase): slot.label
    for phase, slots in PHASES
    for slot in slots
}


class IllegalActionError(ValueError):
    pass


class DraftState:
    """Immutable draft state. bans_by[side] = heroes banned BY side
    (i.e. removed from the opponent's pool)."""

    def __init__(self, roster, bans_by=None, protects_by=None, next_phase=0):
        self.roster = frozenset(roster)
        self.bans_by = bans_by or {BLUE: [], RED: []}
        self.protects_by = protects_by or {BLUE: [], RED: []}
        self.next_phase = next_phase

    def apply_phase(self, phase, actions):
        from src.legal_sets import legal_bans, legal_protects

        if phase != self.next_phase:
            raise IllegalActionError(
                f"expected phase {self.next_phase}, got {phase}"
            )
        if self.next_phase >= len(PHASES):
            raise IllegalActionError(
                f"draft is complete (next_phase={self.next_phase}), cannot apply phase {phase}"
            )
        slots = dict(PHASES)[phase]
        if set(actions) != {s.side for s in slots}:
            raise IllegalActionError(
                f"phase {phase} needs sides {[s.side for s in slots]}, "
                f"got {sorted(actions)}"
            )
        # validate every action against the PRE-phase state
        for slot in slots:
            hero = actions[slot.side]
            legal = (
                legal_bans(self, slot.side)
                if slot.kind == BAN
                else legal_protects(self, slot.side)
            )
            if hero not in legal:
                raise IllegalActionError(
                    f"{slot.side} {slot.kind} {hero!r} illegal at phase {phase}"
                )
        bans = {s: list(v) for s, v in self.bans_by.items()}
        protects = {s: list(v) for s, v in self.protects_by.items()}
        for slot in slots:
            hero = actions[slot.side]
            (bans if slot.kind == BAN else protects)[slot.side].append(hero)
        return DraftState(self.roster, bans, protects, phase + 1)
